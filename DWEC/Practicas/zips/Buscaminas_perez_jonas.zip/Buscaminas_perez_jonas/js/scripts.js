let numeroMinas;
let puntuacion;

iniciarJuego();
function iniciarJuego() {
    const boton = document.getElementById("empezar");
    boton.removeAttribute("hidden");
    const numerMinas = document.getElementById("numMinas");
    numerMinas.removeAttribute("hidden");
    boton.removeEventListener('click', empezar);
    boton.addEventListener('click', empezar);
    }

function empezar() {
    const valor = document.getElementById("numMinas").value;

    if (valor < 5 || valor > 50 || isNaN(valor)) {
        document.getElementById("error").innerHTML = "Tiene que tener un valor entre 5 y 50";
    } else {
        document.getElementById("error").innerHTML = "";
        numeroMinas = parseInt(valor);
        comenzarJuego();
    }
}

function comenzarJuego() {
    const boton = document.getElementById("empezar");
    boton.setAttribute("hidden", "true");
    const numerMinas = document.getElementById("numMinas");
    numerMinas.setAttribute("hidden", "true");

    const tablero = document.querySelector(".casillas");
    tablero.innerHTML = "";

    for (let i = 0; i < 10; i++) {
        const fila = document.createElement("div");

        for (let j = 0; j < 10 ; j++) {
            const casilla = document.createElement("div");
            casilla.classList.add('casilla');
            //casilla.classList.add('oculto');
            fila.appendChild(casilla);
        }
        tablero.appendChild(fila);
    }
    asignarMinas();
    contactoMinas();
    puntuacion = 0;

    const casillas = Array.from(document.querySelectorAll('.casilla'));
    const numMinas = numeroMinas;
    let totalCasillas = casillas.length;
    casillas.forEach(casilla => {
        casilla.addEventListener('click', () => {
            casilla.classList.remove('oculto');
            totalCasillas--;
            let numeroCasilla = parseInt(casilla.textContent) || 0;
            puntuacion += (numeroCasilla + 1) * numMinas;

            const puntosDiv = document.getElementById("puntos");
            puntosDiv.innerHTML = `${puntuacion} <br>puntos`;


            if (casilla.classList.contains('mina')) {
                finalizarJuego(false);
            }else if (totalCasillas === 0) {
                finalizarJuego(true);
            }
        });
        }
    );
}

function asignarMinas() {
    //El numero de minas vendrá determinado por la variable numeroMinas
    const casillas = Array.from(document.querySelectorAll('.casilla'));
    let minasColocadas = 0;

    while (minasColocadas < numeroMinas) {
        const posicion = Math.floor(Math.random() * casillas.length);
        const casilla = casillas[posicion];

        if (!casilla.classList.contains('mina')) {
            casilla.classList.add('mina');
            minasColocadas++;
        }
    }
    console.log("Minas colocadas: ", minasColocadas);
}

function contactoMinas() {
    const casillas = Array.from(document.querySelectorAll('.casilla'));
    const columnas = 10;
    const filas = Math.floor(casillas.length / columnas);

    for (let i = 0; i < casillas.length; i++) {

        if (casillas[i].classList.contains('mina')) {
            continue;
        }

        let numMinasAlrededor = 0;
        const fila = Math.floor(i / columnas);
        const columna = i % columnas;

        for (let direccionFilas = -1; direccionFilas <= 1; direccionFilas++) {
            for (let direccionColumnas = -1; direccionColumnas <= 1; direccionColumnas++) {

                //Posicion de la mina, la salto
                if (direccionFilas === 0 && direccionColumnas === 0) {
                    continue;
                }

                const nuevaFila = fila + direccionFilas;
                const nuevaColumna = columna + direccionColumnas;

                if (nuevaFila >= 0 && nuevaFila < filas && nuevaColumna >= 0 && nuevaColumna < columnas) {
                    const posicion = nuevaFila * columnas + nuevaColumna;
                    if (casillas[posicion] && casillas[posicion].classList.contains('mina')) {
                        numMinasAlrededor++;
                    }
                }
            }
        }

        if (numMinasAlrededor === 1) {
            casillas[i].classList.add('poco');
            casillas[i].textContent = numMinasAlrededor;
        }else if (numMinasAlrededor === 2) {
            casillas[i].classList.add('medio');
            casillas[i].textContent = numMinasAlrededor;
        }else if (numMinasAlrededor >= 3) {
            casillas[i].classList.add('mucho');
            casillas[i].textContent = numMinasAlrededor;
        }
    }
}

function finalizarJuego(resultado) {
    const protector = document.getElementById("protector");
    const mensajeFinal = document.getElementById("mensajeFinal");
    const puntuacionFinal = puntuacion;

    protector.classList.remove('ocultar');
    mensajeFinal.classList.remove('ocultar');

    if (resultado) {
        mensajeFinal.textContent = "Has ganado con "+ puntuacionFinal +" puntos";
    }else {
        mensajeFinal.textContent = "Has perdido con "+ puntuacionFinal + " puntos";
    }


    const volver = document.createElement("button");
    volver.textContent = "Volver a jugar";
    volver.classList.add('volver'); 
    volver.addEventListener('click', () => {
        protector.classList.add('ocultar');
        mensajeFinal.classList.add('ocultar');
        numeroMinas = 0;
        puntuacion = 0;
        mensajeFinal.textContent = "";

        const tablero = document.querySelector(".casillas");
        if (tablero) {
            tablero.innerHTML = "";
        }
        const inputMinas = document.getElementById("numMinas");
        if (inputMinas) {
            inputMinas.value = "";
        }

        const puntosDiv = document.getElementById("puntos");
        if (puntosDiv) {
            puntosDiv.innerHTML = `0 <br>puntos`;
        }

        iniciarJuego();
    });
    mensajeFinal.appendChild(volver);
}